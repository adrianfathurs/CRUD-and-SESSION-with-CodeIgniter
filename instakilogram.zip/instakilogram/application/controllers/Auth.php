<?php 
class Auth extends CI_Controller
{

	public function __construct()
	{
		parent:: __construct();
		$this->load->model('UserModel');
		$this->load->model('PostModel');
	}

	public function index()
	{
		$this->load->view('auth/login');
	}

	public function login()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$result = $this->UserModel->findByEmail($email);

		if ($result) 
		{
			if( password_verify($password, $result['password']) )
			{
				$user = array(
					'login' => $result['email'] );

				//set session
				$this->session->set_userdata($user); //ses

				//pindah halaman user
				redirect(base_url('User'));
			}
			else
			{	
				//set session
				$this->session->set_flashdata('flash', '<script type="text/javascript">window.alert("password tidak ada");</script>');
				redirect(base_url('Auth'));			
			}
		}	
		else
		{
			//set session
			$this->session->set_flashdata('flash', '<script type="text/javascript">window.alert("email tidak ada");</script>');

			redirect(base_url('Auth'));
		}
		
	}

	public function register()
	{
		$this->load->view('auth/register');
	}

	public function create_user()
	{
		$user = [
			'name' => $this->input->post('name'),
			'username' => $this->input->post('username'),
			'email' => $this->input->post('email'),
			'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT)
		];
		$this->UserModel->create($user);

		//set session_decode(data)
		$this->session->set_flashdata('flash', '<script type="text/javascript">window.alert("Data berhasil ditambah");</script>');

		redirect(base_url('Auth'));
	}

	public function logout()
	{
		unset($_SESSION['login']);

		$this->session->set_flashdata('flash', '<script type="text/javascript">window.alert("Berhasil Logout");</script>');
		redirect(base_url('Auth'));
	}
}	

?>
