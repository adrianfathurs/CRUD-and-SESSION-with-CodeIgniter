<?php 
class Post extends CI_Controller
{
	function __construct()
	{
		parent :: __construct();
		$this->load->model('PostModel');
		$this->load->model('UserModel');

		if ( $this->session->userdata('login') == false ) 
		{
			$this->session->set_flashdata('flash', '<script type="text/javascript">window.alert("Login dulu !!");</script>');
			redirect(base_url('Auth'));
		}
	}

	public function index()
	{
		$data['post'] = $this->PostModel->findAll();
		$data['post2'] = $this->PostModel->findAllPost();
		$data['users'] = $this->UserModel->findAll();
		$this->load->view('post/index', $data);
	}

	//method untuk tambah data post
	public function create()
	{
		$post = [
			'user_id' => $this->input->post('user_id'),
			'body' => $this->input->post('body')
		];

		$this->PostModel->create($post);
		redirect(base_url('Post'));
	}

	//method untuk menampilkan data spesifik parameter id
	public function show($id_p)
	{
		$data['post'] = $this->PostModel->findById($id_p);
		$this->load->view('post/showandupdate', $data);
	} 

	//method untuk update data post
	public function update($id_p)
	{
		$post = [
			'id_p' => $id_p,
			'body' => $this->input->post('body'),
			'user_id' => $this->input->post('user_id')
		];
		$data['post'] = $this->PostModel->update($post);
		redirect(base_url('Post'));
	}

	//method untuk menghapus data post
	public function delete($id_p)
	{
		$this->PostModel->delete($id_p);
		redirect(base_url('Post'));
	}
}
?>
