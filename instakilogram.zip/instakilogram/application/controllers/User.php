<?php

class User extends CI_Controller
{
	function __construct()
	{
		parent :: __construct();
		$this->load->model('UserModel');

		if ( $this->session->userdata('login') == false ) 
		{
			$this->session->set_flashdata('flash', '<script type="text/javascript">window.alert("Login dulu !!");</script>');
			redirect(base_url('Auth'));
		}
	}

	public function index()
	{
		$data['users'] = $this->UserModel->findAll();
		$this->load->view('users/index', $data);
	}

	public function register()
	{
		$this->load->view('user/index');
	}

	public function create()
	{
		$user = [
			'name' => $this->input->post('name'),
			'username' => $this->input->post('username'),
			'email' => $this->input->post('email'),
			'password' => $this->input->post('password')
		];
		$this->UserModel->create($user);
		redirect(base_url('User'));
	}

	public function delete($id)
	{
		$this->UserModel->delete($id);
		redirect(base_url('User'));
	}

	public function show($id)
	{
		$data['user'] = $this->UserModel->findById($id);
		$this->load->view('users/update', $data);

	}

	public function update($id)
	{
		$user = [
			'id' => $id,
			'name' => $this->input->post('name'),
			'username' => $this->input->post('username'),
			'email' => $this->input->post('email'),
			'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT)
		];
		$data['user'] = $this->UserModel->update($user);
		redirect(base_url('User'));
	}
}


?>