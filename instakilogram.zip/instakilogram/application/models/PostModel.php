<?php 
class PostModel extends CI_Model
{
	private const TABLE_NAME = 'post';

	//fungsi insert/tambah data
	public function create($post)
	{
		$this->db->insert($this::TABLE_NAME, $post);
	}

	public function findAll()
	{
		return $this->db->from($this::TABLE_NAME)
		->join(UserModel::TABLE_NAME, 'post.user_id = users.id')->get()->result_array();
	}

	public function findAllPost()
	{
		return $this->db->get($this::TABLE_NAME)->result_array();
	}

	public function findById($id_p)
	{
		return $this->db->from($this::TABLE_NAME)
		->join(UserModel::TABLE_NAME, 'post.user_id = users.id')->where('id_p', $id_p)->get()->row_array(); 
	}

	//fungsi hapus data
	public function delete($id_p)
	{
		$this->db->where('id_p', $id_p);
		$this->db->delete($this::TABLE_NAME);
	}

	//fungsi update data
	public function update($post)
	{
		$this->db->update($this::TABLE_NAME, $post, array('id_p' => $post['id_p']));
	}
}
?>

