<?php 

class UserModel extends CI_Model
{
	public const TABLE_NAME = 'users';

	public function create($user)
	{
		$this->db->insert($this::TABLE_NAME, $user);
	}

	public function findAll()
	{
		return $this->db->get($this::TABLE_NAME)->result_array();
	}

	public function findById($id)
	{
		return $this->db->where('id', $id)
						->get($this::TABLE_NAME)->row_array(); 
	}

	public function delete($id)
	{
		$this->db->where('id', $id);
		$this->db->delete($this::TABLE_NAME);
	}

	public function update($user)
	{
		$this->db->update($this::TABLE_NAME, $user, array('id' => $user['id']));
	}

	public function findByEmail($email)
	{
		return $this->db
		->where('email', $email)
		->get($this::TABLE_NAME)->row_array();
	}	
}

?>