<!DOCTYPE html>
<html>
<head>
	<title>Form Login</title>
	<link rel="stylesheet" type="text/css" href="">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/bootstrap.min.css">
</head>
<body>

	<div class="container">	
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<a class="navbar-brand" href="#">Navbar</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
				<div class="navbar-nav">
					<a class="nav-item nav-link" href="<?=base_url('User');?>">User <span class="sr-only">(current)</span></a>
					<a class="nav-item nav-link" href="<?=base_url('User/register');?>">Register</a>
					<a class="nav-item nav-link" href="<?=base_url('Post');?>">Post</a>
					<a class="nav-item nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
				</div>
			</div>
		</nav>
		

		<div class="row mt-3">
			<div class="col">
				<h2 class="text-success">Form Login</h2>
			</div>
		</div>

		<?php if($this->session->flashdata('flash') ) : ?>
			<div class="row">
				<div class="col">
					<?= $this->session->flashdata('flash'); ?>
				</div>
			</div>
		<?php endif; ?>

		<div class="row mt-3">
			<div class="col-md-4">
				<form action="<?=base_url();?>Auth/login" method="post">
					<div class="form-group">
						<label>Email</label>
						<input type="text" class="form-control" name="email" placeholder="masukkan email">
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" name="password" placeholder="masukkan password">
					</div>
					
					<input class="btn btn-success" type="submit" name="" value="Login">
				</form>
			</div>
		</div>
		<div class="row">
			<div class="col">
				<center>
					<p>Belum punya akun? </p><a class="badge badge-success" href="<?=base_url();?>Auth/register">Daftar</a>
				</center>
			</div>
		</div>
		
	</div>

</body>
</html>