<!DOCTYPE html>
<html>
<head>
	<title>Input Post</title>
	<link rel="stylesheet" type="text/css" href="">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/bootstrap.min.css">
</head>
<body>

	<div class="container">	
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<a class="navbar-brand" href="#">Navbar</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
				<div class="navbar-nav">
					<a class="nav-item nav-link" href="<?=base_url('User');?>">User <span class="sr-only">(current)</span></a>
					<a class="nav-item nav-link" href="<?=base_url('User/register');?>">Register</a>
					<a class="nav-item nav-link" href="<?=base_url('Post');?>">Post</a>
					<a class="nav-item nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
				</div>
			</div>
		</nav>
		

		<div class="row mt-3">
			<div class="col">
				<h2 class="text-success">Form Post</h2>
			</div>
		</div>

		<div class="row mt-3">
			<div class="col-md-4">
				<form action="<?=base_url();?>Post/create" method="post">
					<div class="form-group">
						<label>Nama</label>
						<select name="user_id" class="form-control">
							<?php foreach($users as $u) : ?>
							<option value="<?=$u['id'];?>"> <?=$u['name'];?> </option>
							<?php endforeach; ?>
						</select>
					</div>
					<div class="form-group">
						<label>body</label>
						<textarea class="form-control" name="body"></textarea>
					</div>
					<input class="btn btn-success float-right" type="submit" name="submit" value="Kirim">
				</form>
			</div>

			<div class="col-md-8">
				<table class="table">
					<thead class="thead-light">
						<tr>
							<th scope="col">Nama</th>
							<th scope="col">Body</th>
							<th scope="col">Aksi</th>
						</tr>
					</thead>
					<tbody>						
						<?php foreach($post as $p): ?>
						
						<tr>
							<td><a href="<?=base_url();?>Post/show/<?=$p['id_p'];?>"> <?=$p['name'];?> </a></td>
							<td><?=$p['body'];?> </td>
							<td>
								<a href="<?=base_url();?>Post/delete/<?=$p['id_p'];?>" class="badge badge-danger" onclick="return confirm('Yakin dihapus?')">Hapus</a>
							</td>
						</tr>

						
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>

	
		
	</div>


</body>
</html>