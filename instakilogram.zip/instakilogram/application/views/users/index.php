<!DOCTYPE html>
<html>
<head>
	<title>Daftar Data</title>
	<link rel="stylesheet" type="text/css" href="">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/css/bootstrap.min.css">
</head>
<body>

	<div class="container">	
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<a class="navbar-brand text-danger" href="#">Navbar</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
				<div class="navbar-nav">
					<a class="nav-item nav-link" href="<?=base_url('User');?>">User <span class="sr-only">(current)</span></a>
					<a class="nav-item nav-link" href="<?=base_url('User/register');?>">Register</a>
					<a class="nav-item nav-link" href="<?=base_url('Post');?>">Post</a>
					<a class="nav-item nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
				</div>
			</div>
		</nav>

		<div class="row">
			<div class="col">
				<a class="badge badge-danger float-right mt-3" href="<?=base_url();?>Auth/logout">Logout</a>
			</div>
		</div>

		<div class="row mt-3">
			<div class="col">
				<h3 class="text-success">Daftar Data</h3>
			</div>
		</div>

		<div class="row mt-3">
			<div class="col-md-6">
				<table class="table bg-light">
					<thead class="thead-light">
						<tr>
							<th scope="col">ID</th>
							<th scope="col">Nama</th>
							<th scope="col">Username</th>
							<th scope="col">Email</th>
							<th scope="col">Password</th>
							<th scope="col">Aksi</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($users as $u): ?>
						<tr>
							<td><?=$u['id'];?> </td>
							<td><a href="<?=base_url();?>User/show/<?=$u['id'];?>"><?=$u['name'];?></a>   </td>
							<td><?=$u['username'];?> </td>
							<td><?=$u['email'];?> </td>
							<td><?=$u['password'];?> </td>
							<td>
								<a href="<?=base_url();?>User/delete/<?=$u['id'];?>" class="badge badge-danger" onclick="return confirm('Yakin dihapus?')">Hapus</a>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>		
			</div>
		</div>
	</div>

</body>
</html>